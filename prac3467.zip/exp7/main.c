#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <linux/spi/spidev.h> // Include this header for SPI mode definitions
#include "spi.h"

#define SPI_DEVICE "/dev/spidev3.0"

int main(void) {
    uint8_t tx_buffer[32];
    uint8_t rx_buffer[32];
    uint32_t len_data = 32;
    uint32_t spi_speed = 1000000;
    uint32_t spi_mode = SPI_MODE_0;

    for (uint8_t looper = 0; looper < len_data; ++looper) {
        tx_buffer[looper] = looper;
        rx_buffer[looper] = 0xFF;
    }

    int fd = spi_init(SPI_DEVICE, spi_speed);
    if (fd < 0) {
        exit(EXIT_FAILURE);
    }

    if (spi_configure(fd, spi_mode) < 0) {
        spi_close(fd);
        exit(EXIT_FAILURE);
    }

    if (spi_transfer(fd, tx_buffer, rx_buffer, len_data) < 0) {
        spi_close(fd);
        exit(EXIT_FAILURE);
    }

    printf("Received data:\n");
    for (uint8_t looper = 0; looper < len_data; ++looper) {
        printf("0x%02X ", rx_buffer[looper]);
        if ((looper + 1) % 8 == 0)
            printf("\n");
    }

    spi_close(fd);
    return 0;
}

