#include "spi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/spi/spidev.h>

int spi_init(const char *device, uint32_t speed) {
    int fd = open(device, O_RDWR);
    if (fd < 0) {
        perror("Could not open the SPI device");
        return -1;
    }

    int ret = ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed);
    if (ret < 0) {
        perror("Could not set SPI speed");
        close(fd);
        return -1;
    }

    return fd;
}

int spi_configure(int fd, uint32_t mode) {
    int ret;
    ret = ioctl(fd, SPI_IOC_WR_MODE32, &mode);
    if (ret < 0) {
        perror("Could not set SPI mode");
        return -1;
    }

    return 0;
}

int spi_transfer(int fd, uint8_t *tx_buffer, uint8_t *rx_buffer, uint32_t len) {
    struct spi_ioc_transfer trx = {
        .tx_buf = (unsigned long)tx_buffer,
        .rx_buf = (unsigned long)rx_buffer,
        .len = len,
        .speed_hz = 1000000,
        .bits_per_word = 8,
    };

    int ret = ioctl(fd, SPI_IOC_MESSAGE(1), &trx);
    if (ret < 1) {
        perror("Could not perform SPI transfer");
        return -1;
    }

    return 0;
}

void spi_close(int fd) {
    close(fd);
}

